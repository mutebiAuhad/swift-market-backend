# SWIFT MARKET v2.1.0 — latest update

This package upgrades the supplied `swift-market-backend.zip` while preserving its existing API/frontend structure.

## Included updates
- Fixed the first-10-business promotion: exactly 30 days free for qualifying registrations.
- Qualifying launch businesses are active immediately; paid businesses remain pending until subscription payment/activation.
- Added human-friendly Business IDs in the `SWM-XXXXXXXX` format.
- Added migration support so older SQLite databases can receive Business IDs without losing existing records.
- Added product short-video support: MP4, WEBM and MOV, up to 20 MB.
- Added marketplace product/business search.
- Added stronger request security with Helmet and API rate limiting.
- Added safer private admin-panel token comparison.
- Added Flutterwave webhook handling with server-side transaction verification.
- Tightened checkout verification to require exact UGX amount/currency before marking an order paid.
- Added stock checks before final payment confirmation.
- Added order/customer dashboard endpoints already present in the backend and kept them compatible with the existing frontend.
- Added active-subscription enforcement before a business can create listings.
- Updated upload limits and validation for modern product media.
- Updated configuration examples and version information.

## Important production configuration
Real payments still require your own approved Flutterwave/MTN credentials. Do not put card numbers or mobile-money PINs into SWIFT MARKET. Public deployment should use HTTPS, a strong JWT secret, SMTP credentials, and persistent media storage.

The free-launch offer is application logic; payment gateway onboarding, business payout/subaccount onboarding, tax/e-invoicing requirements, and legal/privacy review still need to be completed before public commercial launch.
