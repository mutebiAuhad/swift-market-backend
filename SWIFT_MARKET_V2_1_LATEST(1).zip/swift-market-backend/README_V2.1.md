# SWIFT MARKET v2.1.0

Updated from the supplied `swift-market-backend.zip`.

## Run on Kali/Linux/Windows
1. Install Node.js 20+.
2. Extract this folder.
3. Copy `.env.example` to `.env`.
4. Fill in `JWT_SECRET`, `ADMIN_PASSWORD_HASH`, `ADMIN_ACCESS_TOKEN`, and payment/email credentials when you are ready.
5. Run:

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

## What changed
- First 10 businesses: 30 days free.
- Automatic SWM-XXXXXXXX Business IDs.
- Product photo + short video uploads.
- Product/business search.
- Helmet security headers and API rate limiting.
- Stronger payment verification and Flutterwave webhook endpoint.
- Active subscription required before adding listings.
- Safer private admin-panel token comparison.
- Existing SQLite data gets lightweight migrations for the new fields.

## Payments
Flutterwave handles customer checkout for card, MTN Mobile Money and Airtel Money where enabled for the account. MTN MoMo Collections is used for business subscription requests. Live credentials and provider approval are required; the app does not store card numbers or mobile-money PINs.

## Production
Use HTTPS, a strong unique JWT secret, SMTP app password, provider live credentials, backups and persistent media storage. Review privacy/terms and Uganda tax/e-invoicing obligations before commercial launch.
