// Secure media uploads for SWIFT MARKET.
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const uploadDir = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });

const IMAGE_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp']);
const VIDEO_EXT = new Set(['.mp4', '.webm', '.mov']);
const ALLOWED = new Set([...IMAGE_EXT, ...VIDEO_EXT]);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, `${uuidv4()}${path.extname(file.originalname).toLowerCase()}`),
});

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!ALLOWED.has(ext)) return cb(new Error('Unsupported media type. Use JPG, PNG, WEBP, MP4, WEBM or MOV.'));
    cb(null, true);
  },
});

function urlFor(req, filename) {
  return `${req.protocol}://${req.get('host')}/uploads/${filename}`;
}

module.exports = { upload, urlFor, IMAGE_EXT, VIDEO_EXT };
